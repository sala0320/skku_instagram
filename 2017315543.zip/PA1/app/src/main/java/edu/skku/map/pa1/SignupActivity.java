package edu.skku.map.pa1;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;

public class SignupActivity extends AppCompatActivity {
    Intent intent;
    EditText username, password, fullname, birthday, email;
    Button signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);
        intent = getIntent();

        username = (EditText)findViewById(R.id.username);
        password = (EditText)findViewById(R.id.password);
        fullname = (EditText)findViewById(R.id.fullname);
        birthday = (EditText)findViewById(R.id.birthday);
        email = (EditText)findViewById(R.id.email);
        signup = (Button)findViewById(R.id.signup);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent signupIntent = new Intent(getApplication(),LoginActivity.class);
                signupIntent.putExtra("username", username.getText().toString());
                startActivity(signupIntent);
            }
        });
    }
}
