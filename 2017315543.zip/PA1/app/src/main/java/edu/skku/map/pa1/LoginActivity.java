package edu.skku.map.pa1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class LoginActivity extends AppCompatActivity {
    String user;
    Button loginBtn;
    Intent intent, loginIntent, signupIntent;
    TextView username, password, signup;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        loginBtn = (Button)findViewById(R.id.login);
        username = (TextView)findViewById(R.id.username);
        password = (TextView)findViewById(R.id.password);
        signup = (TextView)findViewById(R.id.signup);
        signupIntent = new Intent(this, SignupActivity.class);
        loginIntent = new Intent(this, MainActivity.class);

        intent = getIntent();
        user = intent.getStringExtra("username");
        username.setText(user);

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(signupIntent);
            }
        });
        loginBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(loginIntent);
            }
        });
    }
}